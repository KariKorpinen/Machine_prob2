
Example use of movielens data in R

First, source all the .R files in the directory:

> source("sourcedir.R")
> sourceDir("./")

Next, load the movielens data (creates the global variables
'ratings','items','userids',and 'itemids' to hold the data)

> loadmovielens()


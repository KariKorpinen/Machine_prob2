
Example use of Movielens data in matlab/octave:

First, load the movielens data:

>> [ratings items userids itemids] = loadmovielens();

